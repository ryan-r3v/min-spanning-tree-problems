This python program was made in and easily runs in visual studio code.

The program asks if the user would like to solve problem 1 or problem 2. When prompted, simply enter "1" or "2" and press enter to run either
problem. A PDF file with the visual representations of both problems 1 and 2 is in the folder. At each iteration of the MST algorithm, the 
program will display the list of connected nodes, the list of unconnected nodes, all of the connecting edges, and the total cost of the tree up 
to that point.

This project for me was much easier to get working properly than the previous two. I was able to work out a system of lists and list operations
to correctly solve MST problems. The program took a surprisingly little amount of testing and revision to get working properly.